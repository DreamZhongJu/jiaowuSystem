<template>
	<div class="admin-update-pwd">
		<update-psd />
	</div>
</template>

<script>
export default {
  name: "AdminUpdatePwd"
}
</script>

<style scoped>
.admin-update-pwd{
    background-color: #fff;
}
</style>
