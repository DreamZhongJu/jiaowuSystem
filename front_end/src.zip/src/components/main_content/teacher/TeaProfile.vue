<template>
	<div class="tea-profile">
		<profile-info />
	</div>
</template>

<script>
export default {
  name: "TeaProfile"
}
</script>

<style scoped>

</style>
