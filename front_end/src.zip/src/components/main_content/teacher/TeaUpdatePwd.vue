<template>
	<div class="tea-update-pwd">
		<update-psd />
	</div>
</template>

<script>
export default {
  name: "TeaUpdatePwd"
}
</script>

<style scoped>
.tea-update-pwd{
    background-color: #fff;
}
</style>
