<template>
	<div class="stu-profile">
		<profile-info />
	</div>
</template>

<script>
export default {
  name: "StuProfile"
}
</script>

<style scoped>

</style>
