<template>
	<div class="update-pwd">
		<update-psd />
	</div>
</template>

<script>
export default {
  name: "UpdatePwd"
}
</script>

<style scoped>
.update-pwd{
    background-color: #fff;
}
</style>
