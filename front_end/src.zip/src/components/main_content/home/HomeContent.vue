<template>
	<div>
		asadad
	</div>
</template>

<script>
export default {
  name: "HomeContent"
}
</script>

<style scoped>

</style>
