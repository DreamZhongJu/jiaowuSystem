const express = require('express');  
const cors = require('cors');

const port = 5000; // 你可以选择任何未被占用的端口  
const db = require('./db')
const bodyParser = require('body-parser');


const app = express();
// 设置中间件以允许跨域请求（可选，根据你的需求）  
app.use((req, res, next) => {  
  res.header("Access-Control-Allow-Origin", "*");  
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");  
  next();  
});  
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

//配置对外接口
app.get('/', (req, res) => {
  var sql = 'select * from user'
  db.query(sql, (err, data) => {
      if(err) {
          return res.send({
            status: 400,
            message: "查询失败"
          })
      } else{
        console.log('查询结果：', data)
		res.json(data); 
      }
  })
});

// 登录接口
app.post('/login', (req, res) => {
  console.log('Request Body:', req.body); // 添加日志
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ message: '用户名或密码不能为空' });
  }

  const query = 'SELECT COUNT(*) AS count FROM account WHERE user_id = ? AND password = ?';
  const values = [username, password];

  db.query(query, values, (err, results) => {
    if (err) {
      console.error('登录查询出错: ', err);
      res.status(500).json({ message: '登录失败' });
      return;
    }

    // 确保 results 不为空
    if (results && results.length > 0) {
      const count = results[0].count;
      if (count === 1) {
        res.status(200).json({ message: '登录成功', token: 'your-generated-token', role: 'student' });
      } else {
        res.status(401).json({ message: '登录失败，用户名或密码错误' });
      }
    } else {
      res.status(401).json({ message: '登录失败，用户名或密码错误' });
    }
  });
});

app.post('/course/getcourse', (req, res) => {
  const query = "SELECT * FROM ez_score";
  // 在此处执行数据库查询操作，并获得结果
  db.query(query, (err, results) => {
    if (err) {
      console.error('查询出错: ', err);
      res.status(500).json({ message: '失败' });
      return;
    }
    // 确保 results 不为空
    if (results.length === 0) {
      res.status(404).json({ message: '没有找到数据' });
      return;
    }
    const jsonData = JSON.stringify(results);
    res.send(jsonData);
  });
});


// 设置路由和响应  
/*
app.get('/', (req, res) => {  
  // 创建一个对象，其中包含你想要返回的数据  
  const data = [  
  { id: 1, name: 'Alice', age:18, email: 'alice@example.com' },  
  { id: 2, name: 'Bob', age:19, email: 'bob@example.com' },  
  // ...更多用户  
  ];  
  
  // 使用res.json()方法发送JSON响应  
  res.json(data);  
});  
*/
const PORT = process.env.PORT || 3000;
// 启动服务器  
app.listen(port, () => {  
  console.log(`Server is running on http://localhost:${port}`);  
});